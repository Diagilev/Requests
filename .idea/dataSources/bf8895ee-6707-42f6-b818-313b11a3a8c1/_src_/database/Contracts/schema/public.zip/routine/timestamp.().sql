CREATE FUNCTION timestamp () RETURNS trigger
	LANGUAGE plpgsql
AS $$
    BEGIN
        NEW.date = NOW();
        RETURN NEW;
    END;
    
$$
